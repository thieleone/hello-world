package U8;

public class Event {
	long timestemp;
	public enum Eventtype{
		EVENT1, EVENT2, EVENT3, EVENT4, EVENT5, EVENT6, EVENT7, EVENT8, EVENT9, EVENT0
	}
	Eventtype etype;
	public String toString(){
		return("Zeitstempel: "+timestemp+" Typ: "+etype);
	}
}
