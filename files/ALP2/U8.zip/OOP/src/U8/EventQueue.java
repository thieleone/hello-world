package U8;

public interface EventQueue {
	public int size();
	
	
	public boolean isEmpty();
	/* Fragt, ob die Warteschlange leer ist */
	
	public void insert(Event event);
	/* Ein Ereignis wird in die Warteschlange nach dem Zeitstempel einsortiert */
	
	public Event first() throws EmptyQueueException;
	/* Das erste Element der Warteschlange wird gelesen */
	
	public Event removeFirst() throws EmptyQueueException;
	
}
