package U8;

public interface Iterator <E> {
	boolean hasNext();
	E next();
}
