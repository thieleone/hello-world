package U8;

public interface Iterable<E> {
	Iterator<E> iterator();
}