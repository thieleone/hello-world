package U8;

public class Simulator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
