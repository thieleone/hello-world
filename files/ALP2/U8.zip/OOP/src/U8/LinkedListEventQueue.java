package U8;

public class LinkedListEventQueue<E> implements Iterable<Event>, EventQueue {
	
	public class ListNode<Event>{
		Event element;
		ListNode <Event> next;
		ListNode( Event element, ListNode<Event> next ){
			this.element = element;
			this.next = next; }
		ListNode( Event element){
			this.element = element;
			this.next = null; }
		ListNode() {
			this( null, null );
		}
	}
	
	public class QueueIterator<Event> implements Iterator<E>{

		ListNode<Event> current;
		QueueIterator(ListNode<Event> head) {
			current = head;
		}
		public boolean hasNext() {
			return (current != null);
		}
		public Event next() {
			if (current == null){
				return null;
			}
			Event eve = current.element;
			current = current.next;
			return eve;
		}
		public void printqueue(Iterator<E> Iter){
			
		}
	}
	private ListNode<Event> head;
	public LinkedListEventQueue() {
		this.head = null;
	}
	/*public String toString(){
		Liste wird mit Iterator durchlaufen, Ausgabe mit .element.toString()
	}*/
	
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return head == null;
	}

	public void insert(Event event) {
		// TODO Auto-generated method stub
		if ( isEmpty() )
			head = new ListNode<Event>(event);
		//else
			
	}

	public Event first() throws EmptyQueueException {
		// TODO Auto-generated method stub
		if(isEmpty()){
			throw new EmptyQueueException();
		}
		else
			return head.element;
	}

	@Override
	public Event removeFirst() throws EmptyQueueException {
		// TODO Auto-generated method stub
		if(isEmpty()){
			throw new EmptyQueueException();
		}
		else{
			Event element = head.element;
			head = head.next;
			return element;
		}
	}

	@Override
	public Iterator<Event> iterator() {
		// TODO Auto-generated method stub
		return null;
	}


}
