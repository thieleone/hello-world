package shapes;

import java.awt.Color;
import java.util.ArrayList;
import java.awt.Graphics;
import java.awt.Polygon;
import java.util.Random;

public class KidnapperBubble extends Bubble{
	ArrayList<Shape> Liste;
	KidnapperBubble(){
		ShapesList Liste=new ShapesList();
	}
	public void play() {
		if (world.getClosestShape(this)!=null){
			if(Liste.contains(world.getClosestShape(this))){
			}
			else if(contains(world.getClosestShape(this).getCenter().x,world.getClosestShape(this).getCenter().y)){
				Liste.add(world.getClosestShape(this));
			}
		}
		if(Liste.size()>0)	{
			for(Shape captured:Liste){
				if(captured!=null){
					if(contains(captured.getCenter().x,captured.getCenter().y)){
					}
				}
				else{
					captured.moveTo(center.x, center.y);
				}
			}
		}
	}
}