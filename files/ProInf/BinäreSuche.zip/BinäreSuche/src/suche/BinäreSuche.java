package suche;

public class Bin�reSuche {

	public int binarySearch(int[] liste, int x){
		if (liste.length == 0){
			return -1;
		}else{
			int links = 0;
			int rechts = liste.length-1;
			int mid = (links+rechts+1)/2;
			while(links <= rechts){
				if(x == liste[mid]){
					return mid;
				} if (x < liste[mid]){
					rechts = mid-1;
				}else{
					links = mid +1;
				}
				mid = (links+rechts+1)/2;
			}
			return -(mid+1);
		}
	}

	public static void main(String[] args) throws Throwable {
		Bin�reSuche test = new Bin�reSuche();
		int[] tempList = new int[]{1,3,5,7,9,12,15,16,18,20,23,25,28,29,37,46,59,69};
		System.out.println( test.binarySearch(tempList, 3));
	}
}
