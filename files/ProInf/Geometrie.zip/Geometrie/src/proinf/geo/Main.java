package proinf.geo;

public class Main {

	//MAIN
	public static void main(String[] args)
	{
		
	}

}
